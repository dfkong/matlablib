function ylabel2(string)

% string_new=['$$' string '$$'];
ylabel(string,'interpreter','tex','fontname','arial','fontsize',16)
function myplot23

figure('position',[7         7        1424         694.5])

subplot 231
set(gca,'position',[0.0735    0.5461    0.2979    0.3775]);

subplot 232
set(gca,'position',[0.3713    0.5461    0.2987    0.3775]);

subplot 233
set(gca,'position',[0.6699    0.5461    0.2992    0.3775]);

subplot 234
set(gca,'position',[0.0735    0.1314    0.2979    0.3775]);

subplot 235
set(gca,'position',[0.3717    0.1314    0.2990    0.3775]);

subplot 236
set(gca,'position',[0.6706    0.1314    0.2999    0.3775]);
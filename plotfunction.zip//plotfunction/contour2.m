function contour2(X,Y,Z,vv)

function figure2

figure
h=get(gcf,'position');
set(gcf,'position',[h(1:3) h(3)/1.6234]);
function title2(t_string)


title(t_string,'interpreter','tex','fontname','arial','fontsize',14)
The functions in plotfunction folder is mainly coded by Adi Liu in USTC 
and Defeng Kong in ASIPP 
If you got same questions please contact dfkong@ipp.ac.cn or lad@ustc.edu.cn
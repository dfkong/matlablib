function ylabel3(string)

% string_new=['$$' string '$$'];
h=ylabel(string,'interpreter','latex','fontname','arial','fontsize',20);
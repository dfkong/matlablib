function xlabel3(string)

% string_new=['$$' string '$$'];
h=xlabel(string,'interpreter','latex','fontname','arial','fontsize',20);
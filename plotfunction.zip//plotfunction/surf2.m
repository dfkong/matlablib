function surf2(varargin)

h=surf(varargin{:});

set(h,'linestyle','none');

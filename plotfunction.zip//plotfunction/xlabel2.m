function xlabel2(string)

% string_new=['$$' string '$$'];
xlabel(string,'interpreter','tex','fontname','arial','fontsize',16)